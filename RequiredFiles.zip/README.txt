HOW TO USE THE CUSTOM STAGELIST CREATOR

1) Go to https://dshayne07.github.io/PMStagelistTool/ and create your own stagelist.
2) After you finish, click on "Save ASM" file. Put the file it downloads into this folder that extracted from this zip file: "Source/Project+"
3) Go back to the root folder and drag and drop "BOOST.txt" into "GCTRealMate.exe"
4) Some code should run and produce a file named "BOOST.GCT" in the root folder
5) Use a program like WinImage to open up your SD card file if you are trying this out with Dolphin.
6) In your SD card, navigate to the Project+ folder on the root
7) Inject your new BOOST.GCT file into the SD card
8) Enjoy your new stagelist!